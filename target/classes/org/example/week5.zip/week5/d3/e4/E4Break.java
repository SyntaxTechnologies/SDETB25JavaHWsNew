package org.example.week5.d3.e4;

public class E4Break {
    public static void main(String[] args) {

        // Declare and initialize the array of items
        String[] items = {"Item1", "Item2", "Defective", "Item3", "Item4"};

        // Iterate through the array using an enhanced for loop
        for (String item : items) {

            // Check if the current item is defective
            if (item.equals("Defective")) {
                System.out.println("Defective item found. Stopping the production line.");
                break;  // Exit the loop
            }

            // Process the current item if it's not defective
            System.out.println("Processing " + item);
        }
    }
}
