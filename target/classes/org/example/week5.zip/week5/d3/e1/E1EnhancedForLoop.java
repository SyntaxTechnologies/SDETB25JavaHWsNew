package org.example.week5.d3.e1;

public class E1EnhancedForLoop {
    public static void main(String[] args) {
        // Declare and initialize the array (11 years: 2025–2035)
        int[] years = new int[11];

        // Fill the array with years 2025 to 2035 using a normal for loop
        for (int i = 0; i < years.length; i++) {
            years[i] = 2025 + i;
        }

        // Print the array values using an enhanced for loop
        for (int year : years) {
            System.out.println(year);
        }
    }
}
