package org.example.week5.d4.e2;

public class E2NestedForLoops {
    public static void printPattern() {
        // 1. Outer Loop: runs 2 times (two full pattern blocks)
        for (int i = 0; i < 2; i++) {

            // 2. Print "SDLC" once per outer loop iteration
            System.out.println("SDLC");

            // 3. Inner Loop: runs 3 times to print "Java"
            for (int j = 0; j < 3; j++) {
                System.out.println("Java");
            }
        }
    }
    public static void main(String[] args) {

        printPattern();

    }
}
