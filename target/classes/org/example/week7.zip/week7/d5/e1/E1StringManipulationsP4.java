package org.example.week7.d5.e1;

public class E1StringManipulationsP4 {
    public static void main(String[] args) {
        String dataString = "HelloLearnJavaWorld";

        // "LearnJava" starts at index 5 and ends before index 14
        String extracted = dataString.substring(5, 14);

        System.out.println(extracted);






    }
}
