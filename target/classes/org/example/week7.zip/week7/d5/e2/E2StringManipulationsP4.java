package org.example.week7.d5.e2;

public class E2StringManipulationsP4 {
    public static void main(String[] args) {
        String textMessage = "Hey! LMK if you are free.";

        String updatedMessage = textMessage.replace("LMK", "Let me know");

        System.out.println(updatedMessage);


    }
}
