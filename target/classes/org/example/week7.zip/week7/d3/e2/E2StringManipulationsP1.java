package org.example.week7.d3.e2;

public class E2StringManipulationsP1 {
    public static void main(String[] args) {
        String name = "Timmy";

        int length = name.length();
        String upper = name.toUpperCase();
        String lower = name.toLowerCase();

        System.out.println("Length of Timmy: " + length);
        System.out.println("Uppercase: " + upper);
        System.out.println("Lowercase: " + lower);


    }
}
