package org.example.week7.d7.e1;

public class E1StringBuilder {
    public static void main(String[] args) {



        StringBuilder sb = new StringBuilder("car");
        sb.reverse();

        System.out.println("Reversed: " + sb.toString());
    }

}
