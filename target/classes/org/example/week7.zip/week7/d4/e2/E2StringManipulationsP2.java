package org.example.week7.d4.e2;

public class E2StringManipulationsP2 {
    public static void main(String[] args) {
        String email = "john.doe@example.com";

        System.out.println(email.contains("@"));
        System.out.println(email.startsWith("info"));
        System.out.println(email.endsWith(".com"));


    }
}
