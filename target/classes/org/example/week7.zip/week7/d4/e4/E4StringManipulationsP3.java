package org.example.week7.d4.e4;

public class E4StringManipulationsP3 {
    public static void main(String[] args) {
        String word = "hello";

        int indexO = word.indexOf('o');
        int indexJ = word.indexOf('j');

        System.out.println("Position of first 'o': " + indexO);
        System.out.println("Position of 'j': " + indexJ);


    }
}
