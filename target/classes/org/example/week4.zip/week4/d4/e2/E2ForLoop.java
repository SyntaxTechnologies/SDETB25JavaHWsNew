package org.example.week4.d4.e2;

public class E2ForLoop {
    public static void main(String[] args) {
        // Use a for loop that starts with i = 1 and continues while i <= 5
        for (int i = 1; i <= 5; i++) {
            System.out.println("Processing order #" + i);
        }
    }
}
