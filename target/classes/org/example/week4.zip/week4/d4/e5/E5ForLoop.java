package org.example.week4.d4.e5;

public class E5ForLoop {
    public static void main(String[] args) {
        // Use a for loop that starts with i = 1 and continues while i <= 10
        for (int i = 1; i <= 10; i++) {
            int result = 3 * i;
            System.out.println("3*" + i + "=" + result);
        }
    }
}
