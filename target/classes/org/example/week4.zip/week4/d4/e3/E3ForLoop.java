package org.example.week4.d4.e3;

public class E3ForLoop {
    public static void main(String[] args) {

        // Objective: Print "Hey, it is year:" followed by the years from 2025 to 2030 (inclusive).
        for (int year = 2025; year <= 2030; year++) {
            System.out.println("Hey, it is year:");
            System.out.println(year);
        }
    }
}
