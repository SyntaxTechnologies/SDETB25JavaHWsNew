package org.example.week4.d4.e1;

public class E1ForLoop {
    public static void main(String[] args) {

        // Create a for loop and Initialize the loop variable to start at 2(i=2).
        for (int i = 2; i <= 14; i++) {

            // Check if the current number is even
            if (i % 2 == 0) {
                System.out.println(i);
            }
        }
    }
}
