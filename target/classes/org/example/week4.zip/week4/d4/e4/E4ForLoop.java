package org.example.week4.d4.e4;

public class E4ForLoop {
    public static void main(String[] args) {
        // Use a for loop that starts with i = 10 and continues while i >= 1
        for (int i = 10; i >= 1; i--) {
            System.out.println(i);
        }

        // Print the New Year message
        System.out.println("Happy New Year!");
    }
}
