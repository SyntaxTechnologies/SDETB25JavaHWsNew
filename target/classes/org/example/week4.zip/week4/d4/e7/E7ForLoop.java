package org.example.week4.d4.e7;

import java.util.Scanner;

public class E7ForLoop {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt the user
        System.out.print("In: ");

        // Read user input
        int x = input.nextInt();


        for (int i = 0; i < x; i++) {
            System.out.print(i + " ");
        }

        input.close();

    }
}
