package org.example.week4.d3.e1;

public class E1WhileLoop {
    public static void main(String[] args) {
        // Declare a counter variable and set it to 0
        int counter = 0;

        // Use a while loop to print numbers from 0 to 8
        while (counter <= 8) {
            System.out.println(counter);
            counter++; // increment counter by 1
        }
    }
}
