package org.example.week4.d3.e4;

public class E4WhileLoop {
    public static void main(String[] args) {
        // Declare a variable i and set it to 7
        int i = 7;
        while (i <= 98) {
            System.out.println(i);
            i += 7; // increment by 7
        }
    }
}
