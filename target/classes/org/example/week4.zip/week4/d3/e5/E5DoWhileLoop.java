package org.example.week4.d3.e5;

public class E5DoWhileLoop {
    public static void main(String[] args) {
        // Declare a counter variable and set it to 0
        int counter = 0;

        // Use a do-while loop to print "Hello World!" 5 times
        do {
            System.out.println("Hello World!");
            counter++;
        } while (counter < 5);
    }
}
