package org.example.week4.d5.e4;

public class E4Arrays {
    public static void main(String[] args) {
        // Create an array of strings and store the values "This", "is", "array", "of", "strings"

        String[] words = {"This", "is", "array", "of", "strings"};


        for (int i = 0; i < words.length; i++) {
            System.out.print(words[i] + " ");
        }

    }
}
