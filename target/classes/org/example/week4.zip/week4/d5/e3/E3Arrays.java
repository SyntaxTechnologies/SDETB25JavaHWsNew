package org.example.week4.d5.e3;

public class E3Arrays {
    public static void main(String[] args) {
        // Create an array of characters and store the values 's', 'a', 'y', 'b', 'n', 'c', 't', 'd', 'a', 'e', 'x'

        char[] letters = {'s', 'a', 'y', 'b', 'n', 'c', 't', 'd', 'a', 'e', 'x'};

        // Print the characters at the indices that form the word "syntax" manually
        System.out.print(letters[0]);  // s
        System.out.print(letters[2]);  // y
        System.out.print(letters[4]);  // n
        System.out.print(letters[6]);  // t
        System.out.print(letters[8]);  // a
        System.out.print(letters[10]); // x






    }
}
