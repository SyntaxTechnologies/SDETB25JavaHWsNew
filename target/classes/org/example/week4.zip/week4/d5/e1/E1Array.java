package org.example.week4.d5.e1;

public class E1Array {
    public static void main(String[] args) {

        int[] numbers = {45, 78, 12, 67, 55};

        // Loop to print values
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
        }

    }
}
