package org.example.week8.d1.e3;

public class E3JavaMethods {
    public static void main(String[] args) {

        TimePrinter.printTime(11, 30);

    }
}