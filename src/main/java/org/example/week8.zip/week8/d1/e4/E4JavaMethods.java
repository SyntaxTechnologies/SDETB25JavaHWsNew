package org.example.week8.d1.e4;

public class E4JavaMethods {
    public static void main(String[] args) {

        System.out.println(NumberChecker.isEven(4));
        System.out.println(NumberChecker.isEven(7));
    }

}
