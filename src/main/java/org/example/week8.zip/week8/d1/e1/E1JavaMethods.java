package org.example.week8.d1.e1;

public class E1JavaMethods {
    public static void main(String[] args) {

        MethodLibrary lib = new MethodLibrary();

        lib.greet();
        lib.farewell();


    }




}
