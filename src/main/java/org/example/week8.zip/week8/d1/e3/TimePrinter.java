package org.example.week8.d1.e3;

public class TimePrinter {
    public static void printTime(int hours, int minutes) {
        System.out.println(hours + ":" + minutes);
    }
}
