package org.example.week8.d1.e4;

public class NumberChecker {
    public static boolean isEven(int num) {
        return num % 2 == 0;
    }
}
