package org.example.week8.d1.e2;

public class Printer {
    public void printNumbers() {
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }
    }
}
