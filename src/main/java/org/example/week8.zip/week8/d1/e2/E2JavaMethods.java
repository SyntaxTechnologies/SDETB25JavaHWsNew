package org.example.week8.d1.e2;

public class E2JavaMethods {
    public static void main(String[] args) {
        Printer printer = new Printer();
        printer.printNumbers();
    }
    }
