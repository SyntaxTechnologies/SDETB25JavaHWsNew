package org.example.week8.d1.e1;

public class MethodLibrary {
    public void greet() {
        System.out.println("Hello, welcome to Java!");
    }

    public void farewell() {
        System.out.println("Goodbye! Have a great day!");
    }
}
