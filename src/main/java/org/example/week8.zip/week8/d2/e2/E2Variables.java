package org.example.week8.d2.e2;

public class E2Variables {

    static String ss = "Welcome To Syntax Technologies";

    public static void main(String[] args) {

        System.out.println(ss);

        System.out.println(E2Variables.ss);

        E2Variables obj = new E2Variables();
        System.out.println(obj.ss);

    }
}
