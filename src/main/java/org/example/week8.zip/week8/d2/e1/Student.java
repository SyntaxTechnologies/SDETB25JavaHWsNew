package org.example.week8.d2.e1;

public class Student {
    int year;
    String schoolName;
    int batchNumber;

}
