package org.example.week8.d2.e3;

public class MessagePrinter {
    public void nonStaticMethod() {
        System.out.println("Programming is amazing.");
    }

    public static void staticMethod() {
        System.out.println("Java is awesome.");
    }
}
