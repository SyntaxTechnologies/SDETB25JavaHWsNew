package org.example.week8.d5.e1;

public class E1Constructor {
    public static void main(String[] args) {

        SyntaxTechnologies s1 = new SyntaxTechnologies();
        SyntaxTechnologies s2 = new SyntaxTechnologies("Syntax", 6, 2020, "07302020");

        s1.display();
        s2.display();


    }
}
