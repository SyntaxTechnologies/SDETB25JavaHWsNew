package org.example.week8.d6.e2;

public class Animal {
    public void displayAnimalInfo() {
        System.out.println("I am an animal.");
    }
}
