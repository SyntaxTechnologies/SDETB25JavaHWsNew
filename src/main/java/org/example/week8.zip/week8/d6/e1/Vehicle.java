package org.example.week8.d6.e1;

public class Vehicle {
    String make;
    int year;

    public void displayInfo() {
        System.out.println("Vehicle: " + make + ", Year: " + year);
    }
}
