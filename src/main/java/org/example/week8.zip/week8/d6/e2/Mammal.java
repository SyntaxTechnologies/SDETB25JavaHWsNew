package org.example.week8.d6.e2;

public class Mammal extends Animal {

    public void displayMammalInfo() {
        System.out.println("I am a mammal.");
    }
}
