package org.example.week8.d6.e1;

public class E1Inheritance {

    public static void main(String[] args) {

        Car car = new Car();

        car.make = "Toyota";
        car.year = 2020;
        car.model = "Corolla";

        car.displayCarInfo();
    }
}
