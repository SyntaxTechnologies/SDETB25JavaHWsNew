package org.example.week8.d6.e2;

public class Dog extends Mammal {

    public void displayDogInfo() {
        System.out.println("I am a dog.");
    }
}
