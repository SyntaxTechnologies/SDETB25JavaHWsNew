package org.example.week8.d6.e2;

public class E2Inheritance {
    public static void main(String[] args) {


        Dog dog = new Dog();

        dog.displayAnimalInfo();
        dog.displayMammalInfo();
        dog.displayDogInfo();

    }
}
