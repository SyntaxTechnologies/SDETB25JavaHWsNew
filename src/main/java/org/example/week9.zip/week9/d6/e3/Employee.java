package org.example.week9.d6.e3;

public class Employee {

    private String empName;
    private int empAge;

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String name) {
        this.empName = name;
    }

    public int getEmpAge() {
        return empAge;
    }

    public void setEmpAge(int age) {
        this.empAge = age;
    }
}