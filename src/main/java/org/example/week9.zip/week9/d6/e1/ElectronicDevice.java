package org.example.week9.d6.e1;

public interface ElectronicDevice {

    void turnOn();

    void turnOff();
}