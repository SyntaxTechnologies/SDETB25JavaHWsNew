package org.example.week9.d6.e2;

public interface Configurable {

    void configure();
}