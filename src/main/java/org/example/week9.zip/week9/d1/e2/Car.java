package org.example.week9.d1.e2;

    public class Car extends Vehicle {
        public Car() {
            super();
        }
    }

