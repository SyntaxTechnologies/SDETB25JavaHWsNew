package org.example.week9.d1.e2;

public class Vehicle {

        public Vehicle() {
            System.out.println("This is the Vehicle constructor");
        }
    }

