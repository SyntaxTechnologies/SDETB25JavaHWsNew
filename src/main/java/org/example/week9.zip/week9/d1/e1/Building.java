package org.example.week9.d1.e1;

public class Building {
    /*
     * 1. Declare a String variable named 'location'.
     * 2. Create a parameterized constructor that takes a String (location) and prints the location.
     *    - For example, if location is "Vienna", the constructor should print "Vienna".
     * 3. Optionally, create a default constructor that prints "Building Constructor".
     */

    String location;

    public Building(String location) {
        this.location = location;
        System.out.println(location);
    }

    public Building() {
        System.out.println("Building Constructor");
    }
}
