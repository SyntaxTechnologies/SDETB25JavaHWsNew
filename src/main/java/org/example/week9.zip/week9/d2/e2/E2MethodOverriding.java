package org.example.week9.d2.e2;

public class E2MethodOverriding {

    public static void main(String[] args) {

        Dog dog = new Dog();
        dog.makeSound();
    }
}




