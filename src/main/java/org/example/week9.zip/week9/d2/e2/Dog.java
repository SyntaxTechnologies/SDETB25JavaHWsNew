package org.example.week9.d2.e2;

public class Dog extends Animal {

        @Override
        public void makeSound() {
            System.out.println("Bark.");
        }
    }


