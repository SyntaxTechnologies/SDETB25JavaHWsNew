package org.example.week9.d2.e2;

public class Animal {

    public void makeSound() {
        System.out.println("Animal sound.");
    }
}

