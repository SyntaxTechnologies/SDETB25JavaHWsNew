package org.example.week9.d4.e1;

public class Animal {
    /*
     * create a public method makeSound() that prints a default message.
     */

    public void makeSound() {
        System.out.println("Animal sound.");
    }
}
