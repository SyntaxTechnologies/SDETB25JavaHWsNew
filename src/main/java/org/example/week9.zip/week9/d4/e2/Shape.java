package org.example.week9.d4.e2;

public class Shape {
    /*
     *    - Write a public method calculateArea() that returns a double.
     *      For now, you can have it return 0.
     */

    public double calculateArea() {
        return 0;
    }
}
