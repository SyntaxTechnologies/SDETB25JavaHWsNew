package org.example.week10.d4.e2;

import java.util.TreeSet;

public class E2Set {

    public static void main(String[] args) {

        TreeSet<String> countries = new TreeSet<>();

        countries.add("India");
        countries.add("Australia");
        countries.add("South Africa");
        countries.add("India");
        countries.add("America");
        countries.add("America");

        System.out.println(countries);


    }

}
